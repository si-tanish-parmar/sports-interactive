const fs = require("node:fs");
// write file 
// read file 
// watch file 

// fs.writeFileSync("temp.txt","welcome to your life");
/*
console.log("log from line 7");
fs.writeFile("temp.txt","welcome to your life", function(error){
    if(error){
        console.log("Error ", error)
    }else{
        console.log("log from line 12");
        console.log("File is ready")
    }
});
console.log("log from line 16");
*/
// console.log( fs.readFileSync("temp.txt", "utf-8") );
/*
fs.readFile("temp.txt","utf-8",function(error, data){
    if(error){
        console.log("Error ", error);
    }else{
        console.log(data)
    }
})
*/