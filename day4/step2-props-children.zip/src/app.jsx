import { Component } from "react";
import Child from "./child";
class App extends Component{
    render(){
        return <div>
                    <h1>App Component</h1>
                    <Child branch="Mumbai" company="Sports Interactive" message="hello first child" version="1001">
                        <h3>Title</h3>
                        <input type="text" />
                        <button>Click Me</button>
                    </Child>
                    <Child branch="Singapore" company="Sports Interactive" message="hello second child" version={2001}>Second</Child>
                    <Child branch="Pune" company="Sports Interactive" message="hello third child" version={3001}>Third</Child>
                    <Child branch="Bangalore" company="Sports Interactive" message="hello fourth child" version={4001}>Fourth</Child>
                </div>
    }
};
export default App;