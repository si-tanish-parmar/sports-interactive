import { Component } from "react";
import NestedChild from "./nestedchild";
class Child extends Component{
    render(){
        return <div>
                    {this.props.children}
                   <h3> {this.props.version + 2}</h3>
                   <h3> {this.props.message.toUpperCase()}</h3>
                   <h3>Company {this.props.company } | Branch { this.props.branch }</h3>
                    <NestedChild {...this.props}/>
                </div>
    }
};
export default Child;