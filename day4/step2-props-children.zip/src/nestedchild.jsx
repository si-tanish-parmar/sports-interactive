import { Component } from "react";

class NestedChild extends Component{
    render(){
        return <div>
            <h1>Message {this.props.message}</h1>
            <h1>Version {this.props.version}</h1>
        </div>
    }
}

export default NestedChild;