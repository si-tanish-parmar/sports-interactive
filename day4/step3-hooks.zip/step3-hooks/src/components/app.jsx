import First from "./first";
import Second from "./second";

export let App = () => <div>
    <h1>App Component</h1>
    <First/>
    <Second/>
</div>