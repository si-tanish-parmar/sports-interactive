import React, { useRef, useState } from "react"

let App = ()=>{
    let [power, setPower] = useState(0);
    let [avengers, setAvengers] = useState([]);

    function clickHandler(){
        // alert("do you want to add an avenger")
        // setAvengers();
        // alert(ipref.current.value);
        setAvengers([...avengers,ipref.current.value]);
        ipref.current.value = "";

    }
    // let ipref = React.createRef();
    let ipref = useRef();
    return <div>
                <h1>State as Number Example</h1>
                <h2>Power : { power }</h2>
                <button onClick={()=> setPower(power+=1)}>Increase Power</button>
                <button onClick={()=> setPower(power-=1)}>Decrease Power</button>
                <hr />
                <hr />
                {/* i am a multiline comment  */}
                <label htmlFor="navenger">Add New Avenger : </label>
                <input id="navenger" ref={ipref} type="text" />
                <button onClick={clickHandler}>Add Avenger</button>
                <ol>
                    {
                        avengers.map((val, idx) => <li key={idx}>{ val }</li>)
                    }
                </ol>
            </div>
}

export default App;