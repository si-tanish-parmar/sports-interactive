import { useRef, useState } from "react";

let App = () => {
    /*
    */
    let [firstname, setFirstName] = useState("Bruce");
    let [lastname, setLastName] = useState("Wayne");
    let fnRef = useRef();
    let lnRef = useRef();
    let changeFirstName = function(){
        setFirstName(fnRef.current.value);
    }
    let changeLastName = function(){
        setLastName(lnRef.current.value);
    }
    return <div>
                <h1>Multiple States</h1>
                <hr />
                <label htmlFor="fname">First Name : </label>
                {/* <input id="fname" onBlur={(evt)=> setFirstName(evt.target.value)} type="text" /> */}
                <input ref={fnRef} id="fname" />
                <button onClick={changeFirstName}>Set First Name</button>
                <br />
                <label htmlFor="lname">Last Name : </label>
                {/* <input id="lname" onBlur={(evt)=> setLastName(evt.target.value)} type="text" /> */}
                <input ref={lnRef} id="lname"  />
                <button onClick={changeLastName}>Set Last Name</button>
                <br />
                <h2>First Name : { firstname }</h2>
                <h2>Last Name : { lastname }</h2>
           </div>
}

export default App;