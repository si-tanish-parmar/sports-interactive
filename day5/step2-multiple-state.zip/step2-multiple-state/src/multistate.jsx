import { useReducer, useRef, useState } from "react";
let MultiState = () => {
    // let [userinfo, setFullName] = useState({ firstname : "Bruce", lastname : "Wayne" });
    
    let fnRef = useRef();
    let lnRef = useRef();
    let ctyRef = useRef();
    
    let reducerFun = (state, action)=>{
        switch(action.type){
            case "CHANGEFIRSTNAME": return { ...state, firstname : action.payload }
            case "CHANGELASTNAME" : return { ...state, lastname : action.payload }
            case "CHANGECITY" : return { ...state, usercity : action.payload }
            default : return state
        }
    };
    
    // let [userinfo, setFullName] = useState({ firstname : "Bruce", lastname : "Wayne" });
    let [store, dispatch] = useReducer(reducerFun,{ firstname : "Bruce", lastname : "Wayne" , usercity : "Gotham"})
    return <div>
        <h1>Multi States</h1>
        <hr />
        <label htmlFor="fname">First Name : </label>
        <input ref={fnRef} onBlur={(evt)=> dispatch({ type : "CHANGEFIRSTNAME", payload : evt.target.value })} id="fname" />
        <br />
        <label htmlFor="lname">Last Name : </label>
        <input ref={lnRef} onBlur={(evt)=> dispatch({ type : "CHANGELASTNAME", payload : evt.target.value })} id="lname"  />
        <br />
        <label htmlFor="ucity">City : </label>
        <input ref={ctyRef} onBlur={(evt)=> dispatch({ type : "CHANGECITY", payload : evt.target.value })} id="ucity"  />
        <br />
        <h2>First Name : { store.firstname }</h2>
        <h2>Last Name : { store.lastname }</h2>
        <h2>City : { store.usercity }</h2>
           </div>
}

export default MultiState;