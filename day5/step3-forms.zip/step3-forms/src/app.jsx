import { useState } from "react";

let App = () => {
    let [user, setUser] = useState({ firstname : "", lastname : "" , age : 0 });

    /*
    let firstnameHandler = (evt) => {
        setUser({...user, firstname : evt.target.value })
    };
    let lastnameHandler = (evt) => {
        setUser({...user, lastname : evt.target.value })
    };
    let ageHandler = (evt) => {
        setUser({...user, age : evt.target.value })
    };
    */

    let formChangeHandler = (evt) => {
        setUser({...user, [evt.target.id] : evt.target.value })
    };
    
    let formSubmitHandler = (evt)=>{
        evt.preventDefault();
        if(user.age < 18){
            alert("you are too young to join us")
        }else if(user.age > 90){
            alert("you are too old to join us")
        }else{
            alert("you are good to join us")
            // console.log(evt);
            evt.target.submit();
        }
    };

    return <div className="container">
                <h2>User Registeration Form</h2>
                <hr />
                <form onSubmit={formSubmitHandler} action="#" method="get">
                    <div className="mb-3">
                        <label htmlFor="firstname" className="form-label">First Name </label>
                        <input onChange={formChangeHandler} name="firstname" value={user.firstname} className="form-control" id="firstname" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="lastname" className="form-label">Last Name </label>
                        <input onChange={formChangeHandler} name="lastname" value={user.lastname} className="form-control" id="lastname" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="age" className="form-label">Age</label>
                        <input onChange={formChangeHandler} name="age" value={user.age} type="range" className="form-control" id="age" />
                    </div>
                    <div className="mb-3">
                        <button type="submit" className="btn btn-primary">Submit</button>
                    </div>
                </form>
            <hr/>
            <ul>
                <li>First Name : { user.firstname }</li>
                <li>Last Name : { user.lastname }</li>
                <li>Age : { user.age }</li>
            </ul>
            </div>
}

export default App;