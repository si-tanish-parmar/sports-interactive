import GrandParentComponent from "./components/grandparent";

let App = () => {
    return <div>
        <h1>Using Context API</h1>
        <hr />
        <GrandParentComponent/>
    </div>
}

export default App;