import { useContext } from "react";
import FamilyContext from "../contexts/family.context";

let ChildComponent = () => {
    let message = useContext(FamilyContext);
    return <div style={ {border : "2px solid grey", padding : "10px"} }>
                <h1>Child Component</h1>
                <h2>Message is : { message }</h2>
            </div>
}

export default ChildComponent;