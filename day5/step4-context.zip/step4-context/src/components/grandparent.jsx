import { useState } from "react";
import FamilyContext from "../contexts/family.context";
import ParentComponent from "./parent";
import CousinComponent from "./cousin";

let GrandParentComponent = () => {
    let [message, setMessage] = useState("")
    return <div style={ {border : "2px solid grey", padding : "10px"} }>
                <h1>Grand Parent Component</h1>
                <input style={ {padding : "10px", margin : "10px"} } type="text" value={message} onChange={(evt)=> setMessage( evt.target.value )} />
                <FamilyContext.Provider value={message}>
                    <ParentComponent/>
                    <CousinComponent/>
                </FamilyContext.Provider>
            </div>
}

export default GrandParentComponent;