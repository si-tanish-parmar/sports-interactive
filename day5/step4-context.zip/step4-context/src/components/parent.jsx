import ChildComponent from "./child";

let ParentComponent = () => {
    return <div style={ {border : "2px solid grey", padding : "10px"} }>
                <h1>Parent Component</h1>
                <ChildComponent/>
            </div>
}

export default ParentComponent;