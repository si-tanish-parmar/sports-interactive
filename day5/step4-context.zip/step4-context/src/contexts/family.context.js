import React from "react";

let FamilyContext = React.createContext();

export default FamilyContext;

/*
FamilyContext.Consumer // recieve
FamilyContext.Provider // send 
*/