let redux = require("redux");
let createStore = redux.legacy_createStore;
let combineReducers = redux.combineReducers;

// action
const ADDHERO = "ADDHERO";
const REMOVEHERO = "REMOVEHERO";

// action
const ADDMOVIE = "ADDMOVIE";
const REMOVEMOVIE = "REMOVEMOVIE";

// action object creator
const addHero = ()=> {
    return {
        type : ADDHERO
    }
}
const removeHero = ()=> {
    return {
        type : REMOVEHERO
    }
}
const addMovie = ()=> {
    return {
        type : ADDMOVIE
    }
}
const removeMovie = ()=> {
    return {
        type : REMOVEMOVIE
    }
}
// intial State
const initalHeroState = {
    numberOfHeroes : 0
};
const initalMovieState = {
    numberOfMovies : 0
};

// reducer
let heroReducerFun = (state = initalHeroState, action)=>{
    switch(action.type){
        case ADDHERO : return { ...state, numberOfHeroes : state.numberOfHeroes+1 }
        case REMOVEHERO : return { ...state, numberOfHeroes : state.numberOfHeroes-1 }
        default : return state
    }
};
let movieReducerFun = (state = initalMovieState, action)=>{
    switch(action.type){
        case ADDMOVIE : return { ...state, numberOfMovies : state.numberOfMovies+1 }
        case REMOVEMOVIE : return { ...state, numberOfMovies : state.numberOfMovies-1 }
        default : return state
    }
};

// 
let rootReducer = combineReducers({
    hero : heroReducerFun,
    movie : movieReducerFun
})

// store
let store = createStore(rootReducer);

console.log(store.getState());

// subscribe and unsubscribe 
let unsubscribe = store.subscribe(function(){
    console.log(store.getState());
});

store.dispatch(addHero());
store.dispatch(addHero());
store.dispatch(removeHero());
store.dispatch(addHero());
store.dispatch(removeHero());
store.dispatch(addMovie());
store.dispatch(addMovie());
store.dispatch(addMovie());
store.dispatch(addHero());
store.dispatch(addHero());
store.dispatch(removeHero());
store.dispatch(addHero());
store.dispatch(addMovie());
store.dispatch(removeMovie());
store.dispatch(addMovie());
store.dispatch(removeMovie());
store.dispatch(addMovie());
// unsubscribe();
store.dispatch(addMovie());
store.dispatch(removeMovie());
store.dispatch(addMovie());

