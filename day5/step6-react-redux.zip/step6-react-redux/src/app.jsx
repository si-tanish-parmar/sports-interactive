import { Provider } from "react-redux";
import HeroComp from "./components/hero.component";
import HeroHookComp from "./components/hero.component.hooks";
import store from "./redux/store";

let App = () => {
    return <div>
                <h1> React Redux Application </h1>
                <Provider store={ store }>
                    <HeroComp/>
                </Provider>
                <Provider store={ store }>
                    <HeroHookComp/>
                </Provider>
            </div>

}

export default App;