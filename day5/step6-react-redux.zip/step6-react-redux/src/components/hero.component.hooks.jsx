import { useDispatch, useSelector } from "react-redux";
import { addHero } from '../redux/index';


function HeroHookComp(){
    const numberOfHeroes = useSelector( state => state.numberOfHeroes);
    const dispatch = useDispatch();

    return <div>
            <h1>Avengers Recruitment Program with hooks</h1>
            <h2>Number of Avengers Enrolled : { numberOfHeroes } </h2>
            <button onClick={ ()=> dispatch( addHero() ) }>Add Avenger</button>
        </div>
}

export default HeroHookComp