// action creator

import { ADD_HERO } from "../types/hero.types"

const addHero = ()=>{
    return { 
        type : ADD_HERO
    }
};

export default addHero;