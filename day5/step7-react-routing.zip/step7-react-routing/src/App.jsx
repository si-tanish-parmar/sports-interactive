import React from "react";
import { BrowserRouter, Routes, Route, Navigate, Link, NavLink } from "react-router-dom";
import HomeComp from "./components/home.component";
/* 
import AquamanComp from "./components/aquaman.component";
import BatmanComp from "./components/batman.component";
import SupermanComp from "./components/superman.component";
import WonderWomanComp from "./components/wonderwomen.component"; 
import NotFoundComp from "./components/notfound";
*/
import "./components/routestyle.css";
import { Suspense, useState } from "react";

let App = () => {
  let [power, setPower] = useState(0);
  // lazy loading 

  let BatmanComp = React.lazy(()=> import('./components/batman.component'));
  let SupermanComp = React.lazy(()=> import('./components/superman.component'));
  let AquamanComp = React.lazy(()=> import('./components/aquaman.component'));
  let WonderWomanComp = React.lazy(()=> import('./components/wonderwomen.component'));
  let NotFoundComp = React.lazy(()=> import('./components/notfound'));

  //------------
  return <div className="container">
          <h1>React Routing</h1>
          <h2>Power is { power }</h2>
          <input type="range" onInput={ (evt)=> setPower(Number(evt.target.value))} />
          <BrowserRouter>
          {/* Navigation */}
          {/* WRONG 
          <ul>
            <li><a href="/">Home</a></li>
            <li><a href="/batman">Batman</a></li>
            <li><a href="/superman">Superman</a></li>
            <li><a href="/aquaman">Aquaman</a></li>
            <li><a href="/wonderwomen">Wonder Women</a></li>
            <li><a href="/flash">Flash</a></li>
            <li><a href="/cybor">Cyborg</a></li>
          </ul> 
          */}
          {/* 
          SIMPLE ROUTING
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/batman">Batman</Link></li>
            <li><Link to="/superman">Superman</Link></li>
            <li><Link to="/aquaman">Aquaman</Link></li>
            <li><Link to="/wonderwomen">Wonder Women</Link></li>
            <li><Link to="/flash">Flash</Link></li>
            <li><Link to="/cybor">Cyborg</Link></li>
          </ul> 
          */}
          {/* Styled Routes */}
          <ul>
            <li><NavLink className={({isActive})=> isActive ? 'box' : null } to="/">Home</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box' : null } to="/batman">Batman</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box' : null } to={'/superman/'+power}>Superman</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box' : null } to="/aquaman">Aquaman</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box' : null } to="/wonderwomen">Wonder Women</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box' : null } to="/flash">Flash</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box' : null } to="/cybor">Cyborg</NavLink></li>
          </ul> 
          {/* Routes Configuration */}
            <Routes>
              <Route path="/" element={<HomeComp/>}/>{/* Default Route */}
              <Route path="/batman" element={ <Suspense fallback={<> Loading ... </>}><BatmanComp/></Suspense> }/>{/* Named Route */}
              <Route path="/superman/" element={<Suspense fallback={<> Loading ... </>}><SupermanComp/></Suspense>}>
                <Route path=":qty" element={<Suspense fallback={<> Loading ... </>}><SupermanComp/></Suspense>}/>
              </Route>{/* Named Route */}
              <Route path="/aquaman" element={<Suspense fallback={<> Loading ... </>}><AquamanComp/></Suspense>}/>{/* Named Route */}
              <Route path="/wonderwomen" element={<Suspense fallback={<> Loading ... </>}><WonderWomanComp/></Suspense>}/>{/* Named Route */}
              <Route path="/flash" element={<Navigate to="/batman" replace />}/>{/* Forwarding Route */}
              <Route path="*" element={<Suspense fallback={<> Loading ... </>}><NotFoundComp/></Suspense>} />{/* Catch All Route */}
            </Routes>
          </BrowserRouter>
         </div>
}
export default App;
