const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const config = require("./config.json");

let app = express();
app.use(express.json());
app.use(cors());

let url = "mongodb+srv://{admin}:{password}@sportsinteractivecluste.{dbstring}.mongodb.net/{dbname}?retryWrites=true&w=majority"
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let Hero = mongoose.model("Hero", new Schema({
    id : ObjectId,
    title : String,
    firstname : String,
    lastname : String,
    power : String,
    city : String
}));

let dburl = url.replace("{admin}", config.username).replace("{password}", config.password).replace("{dbstring}", config.dbstring).replace("{dbname}", config.dbname);
mongoose.set('strictQuery', true);
mongoose.connect(dburl)
.then(res => console.log("DB Connected"))
.catch(err => console.log("Error ", err));

// READ
app.get("/data", (req,res)=>{
    Hero.find().then( dbres => res.json(dbres) )
});

// CREATE
app.post("/data", (req, res)=>{
    let hero = new Hero(req.body);
    hero.save()
    .then( dbres => {
        console.log("hero was added");
        res.json({ message : "hero was added", title : dbres.title})
    })
    .catch( err => console.log("error occured", err))
});
// DELETE :/id
app.delete("/delete/:id",(req, res)=>{
    Hero.findByIdAndDelete(req.params.id)
    .then( dbres => {
        console.log("Deleted ", dbres.title );
        res.json({message : "hero deleted", title : dbres.title })
    })
    .catch( error => console.log("Error ", error))
});

// READ TO UPDATE :/id
app.get("/edit/:id", (req, res)=>{
    Hero.findById({ _id : req.params.id })
    .then(dbres => res.json(dbres))
    .catch(error => console.log("Error ", error));
});

// UPDATE :/id 
app.post("/edit/:id", (req, res)=>{
    Hero.findById({ _id : req.params.id })
    .then(dbres => {

        dbres.title = req.body.title;
        dbres.firstname = req.body.firstname;
        dbres.lastname = req.body.lastname;
        dbres.power = req.body.power;
        dbres.city = req.body.city;

        dbres.save().then(updateSuccess => {
            res.json({message : updateSuccess.title+" was updated"})
        }).catch(updateError => console.log("Error ", updateError ))
    })
    .catch(error => console.log("Error ", error));
});

app.listen(config.port, config.host, function(error){
    if(error){ console.log( "Error", error )}
    else{ console.log("Server is now live on localhost:4000")}
});
