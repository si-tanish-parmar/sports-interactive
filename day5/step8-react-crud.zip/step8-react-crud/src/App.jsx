import { useState } from "react";
import axios from "axios";
import { useEffect } from "react";

let App = () => {
  let [show, setShow] = useState(false);
  let [heros, setHeroData] = useState([]);
  let [hero, setHero] = useState({ title : '', firstname : '', lastname : '', city : '', power : 0 });
  let [edit_hero, updateHero] = useState({ title : '', firstname : '', lastname : '', city : '', power : 0, _id:'' });
  // let [errors, setErrorData] = useState({});

  let refresh = ()=>{
    axios.get("http://localhost:4000/data")
    .then( res => setHeroData( res.data ))
    .catch( err => console.log("Error ", err))
  }
  
  useEffect(()=>{
    refresh();
  },[]);

  let addHandler = (evt)=>{
    setHero({
        ...hero,
        [evt.target.id] : evt.target.value
    })
  };
  let editHandler = (evt)=>{
    updateHero({
        ...edit_hero,
        [evt.target.title] : evt.target.value
    })
  };

  let editInfoHandler = (evt)=>{
    //  evt.target.getAttribute("data-id");
    axios.get("http://localhost:4000/edit/"+evt.target.getAttribute("data-id")).then(res => {
      updateHero(res.data);
      setShow(true);
    })
  }
  let deleteHandler = (evt)=>{
    alert(evt.target.getAttribute("data-id"));
  }
  let updateHeroInfo = ()=>{
     axios.post("http://localhost:4000/edit/"+edit_hero._id, edit_hero)
     .then(res => {
      refresh();
      updateHero({ title : '', firstname : '', lastname : '', city : '', power : 0, _id:'' });
      setShow(false);
     })
     .catch(err => console.log(err))
     
  }
  let addNewHero = ()=>{
    axios.post("http://localhost:4000/data", hero)
    .then( res => {
      refresh();
      setHero({ title : '', firstname : '', lastname : '', city : '', power : 0 });
      console.log(res.message)
    })
    .catch( err => console.log("Error ", err))
  }

  return <div className="container">
          <h1>CRUD in React</h1>
          {/* CREATE HERO */}
          { !show && <div>
            <h2>Add New Hero</h2>
            <div className="mb-3">
                <label htmlFor="title" className="form-label">Hero Title</label>
                <input onChange={ addHandler } value={hero.title} className="form-control" id="title"/>
            </div>
            <div className="mb-3">
                <label htmlFor="firstname" className="form-label">Hero First Name</label>
                <input onChange={ addHandler } value={hero.firstname} className="form-control" id="firstname"/>
            </div>
            <div className="mb-3">
                <label htmlFor="lastname" className="form-label">Hero Last Name</label>
                <input onChange={ addHandler } value={hero.lastname} className="form-control" id="lastname"/>
            </div>
            <div className="mb-3">
                <label htmlFor="power" className="form-label">Hero Power</label>
                <input onChange={ addHandler } value={hero.power} type="range" min="0" max="10" className="form-control" id="power"/>
            </div>
            <div className="mb-3">
                <label htmlFor="city" className="form-label">Hero City</label>
                <input onChange={ addHandler } value={hero.city} className="form-control" id="city"/>
            </div>
            <button onClick={addNewHero} type="submit" className="btn btn-primary">Submit</button>
          </div>}

          {/* EDIT HERO */}

          { show && <div>
            <h2>Edit Hero Info</h2>
            <div className="mb-3">
                <label htmlFor="title" className="form-label">Edit Title</label>
                <input onChange={ editHandler } value={edit_hero.title} className="form-control" title="title"/>
            </div>
            <div className="mb-3">
                <label htmlFor="firstname" className="form-label">Edit First Name</label>
                <input onChange={ editHandler } value={edit_hero.firstname} className="form-control" title="firstname"/>
            </div>
            <div className="mb-3">
                <label htmlFor="lastname" className="form-label">Edit Last Name</label>
                <input onChange={ editHandler } value={edit_hero.lastname} className="form-control" title="lastname"/>
            </div>
            <div className="mb-3">
                <label htmlFor="power" className="form-label">Edit Power</label>
                <input onChange={ editHandler } value={edit_hero.power} type="range" min="0" max="10" className="form-control" title="power"/>
            </div>
            <div className="mb-3">
                <label htmlFor="city" className="form-label">Edit City</label>
                <input onChange={ editHandler } value={edit_hero.city} className="form-control" title="city"/>
            </div>
            <button onClick={updateHeroInfo} type="submit" className="btn btn-primary">Update Hero Info</button>
          </div>}

          <table className="table table-striped table-bordered">
            <thead>
              <tr>
                <th>Sl #</th>
                <th>Title</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>City</th>
                <th>Power</th>
                <th>Edit Info</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              { heros.map( (res, idx) => {
                return <tr key={res._id}>
                        <td>{ idx+1 }</td>
                        <td>{res.title}</td>
                        <td>{res.firstname}</td>
                        <td>{res.lastname}</td>
                        <td>{res.city}</td>
                        <td>{res.power}</td>
                        <td> <button onClick={editInfoHandler} data-id={res._id} className="btn btn-warning">Edit Info</button> </td>
                        <td> <button onClick={deleteHandler} data-id={res._id} className="btn btn-danger">Delete</button> </td>
                      </tr>
              }) }
            </tbody>
          </table>
          {/* <ul>
            <li>{ edit_hero.title }</li>
            <li>{ edit_hero.firstname }</li>
            <li>{ edit_hero.lastname }</li>
            <li>{ edit_hero.power }</li>
            <li>{ edit_hero.city }</li>
          </ul> */}
        </div>
}
export default App;
