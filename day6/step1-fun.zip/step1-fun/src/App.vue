<template>
  <div>
      <h1>Hello From App Component</h1>
      <HeaderComp/>
      <MainComp>
        <ArticleComp/>
        <ArticleComp/>
        <ArticleComp/>
      </MainComp>
      <FooterComp/>
  </div>
</template>
<script>
  import HeaderComp from './components/HeaderComp.vue';
  import MainComp from './components/MainComp.vue';
  import FooterComp from './components/FooterComp.vue';
import ArticleComp from './components/ArticleComp.vue';
  
  export default {
    name : "App",
    components : {
    HeaderComp,
    FooterComp,
    MainComp,
    ArticleComp
}
  }
  
</script>
<style></style>