<template>
    <div class="box">
       Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident ut, doloremque itaque excepturi sint nihil at voluptatibus ullam corporis exercitationem porro accusantium consequuntur accusamus quasi laboriosam magni quo, molestiae dicta?
       Lorem ipsum dolor sit amet consectetur, adipisicing elit. Beatae placeat, excepturi voluptatibus dolorem perspiciatis blanditiis adipisci facere. Eaque repellendus iure vel totam, tenetur maiores tempora aliquid, quasi libero blanditiis architecto?
       Lorem ipsum dolor, sit amet consectetur adipisicing elit. Distinctio reiciendis, quas dolore odit architecto quidem iusto sequi modi est aut enim corrupti earum ut repudiandae eligendi pariatur exercitationem fuga minima!
       Lorem ipsum dolor, sit amet consectetur adipisicing elit. Beatae accusamus consequatur, aspernatur quo at distinctio velit porro nam vitae veniam explicabo repellendus! Qui nobis sequi aliquid asperiores, inventore distinctio similique!
       Lorem ipsum dolor sit, amet consectetur adipisicing elit. Corporis repellat voluptates velit harum obcaecati nobis autem consequuntur soluta dolor expedita. Vero ipsum nisi earum voluptate provident quisquam ab molestias alias!
    </div>
</template>
<script>
    export default {
        name : "ArticleComp"
    }
</script>
<style>
    .box{
        border: 1px solid darkgray;
        font-family: sans-serif;
        text-align: justify;
        padding: 10px;
        margin: 10px;
    }
</style>