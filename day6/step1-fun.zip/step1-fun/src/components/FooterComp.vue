<template>
    <div class="box">
        <h3> &copy; Copyrights reserved by Sports Interactive India</h3>
    </div>
</template>
<script>
    export default {
        name : "FooterComp"
    }
</script>
<style>
    .box{
        border: 1px solid darkgray;
        padding: 10px;
        margin: 10px;
    }
</style>