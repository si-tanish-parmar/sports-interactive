<template>
    <div class="box">
        <h1>Sports Interactive</h1>
        <h2>Mumbai</h2>
    </div>
</template>
<script>
    export default {
        name : "HeaderComp"
    }
</script>
<style>
    .box{
        border: 1px solid darkgray;
        padding: 10px;
        margin: 10px;
    }
</style>