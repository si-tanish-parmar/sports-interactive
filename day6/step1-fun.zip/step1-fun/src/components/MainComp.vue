<template>
    <div class="box">
        <h1>About Sports Interactive</h1>
        <slot></slot>
    </div>
</template>
<script>
    export default {
        name : "MainComp",
    }
</script>
<style>
    .box{
        border: 1px solid darkgray;
        padding: 10px;
        margin: 10px;
    }
</style>