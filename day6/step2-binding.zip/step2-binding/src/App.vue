<template>
  <div>
    <h1>Binding in VUE </h1>
    <hr>
    <h2>{{ title }}</h2>
    <h2 :innerHTML="title"></h2>
    <h2 :innerText="title"></h2>
    <h2 :textContent="title"></h2>
    <div v-html="linkTag"></div>
    <div v-text="linkTag"></div>
    <section :class="selectedClass">
      i am a section
    </section>
    <article :id="selectedId">
      i am an article
    </article>
    <button :disabled="show">Click Me</button>
    <br>
    <input v-model="show" type="checkbox">
    <br>
    <input v-model="title" type="text">
    <br>
    <fieldset :hidden="show">
      <legend>Terms and Conditions</legend>
      <p>
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Commodi quam quod adipisci repellat. Officia aut facere, impedit, quisquam sint, repellendus dolorum ratione unde quam perferendis saepe eum odio perspiciatis earum.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi cumque voluptatem accusamus dignissimos quo, deserunt laudantium tempora tenetur modi adipisci minima nam optio numquam impedit provident possimus facere culpa laboriosam?
      </p>
    </fieldset>
  </div>
</template>

<script>
export default {
  name: 'App',
  data(){
    return {
      title : "Sports Interactive Mumbai",
      linkTag : "<li><a href='https://google.com'>New Name </a> </li>",
      show : true,
      selectedClass : 'box',
      selectedId : 'player'
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  text-align: center;
  color: #2c3e50;
}
#player{
  width: 100px;
  height: 100px;
  margin: auto;
  background-color: rgb(32, 252, 211);
  text-align: center;
  font-family: sans-serif;
  color: rgb(38, 12, 91);
}
.box{
  margin: auto;
  width: 200px;
  height: 100px;
  background-color: crimson;
  text-align: center;
  font-family: sans-serif;
  color: papayawhip;
}
</style>
