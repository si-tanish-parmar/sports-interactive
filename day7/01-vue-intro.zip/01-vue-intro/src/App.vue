<template>
  <main-app msg="Welcome to Your Life"></main-app>
</template>

<script>
import MainApp from './components/MainApp.vue'

export default {
  name: 'App',
  components: {
    MainApp
  }
}
</script>

<style>
#app {
  font-family: sans-serif;
}
</style>
