<template>
    <footer>
        <h4>&copy; copyrights reserved by sports interactive mumbai</h4>
    </footer>
</template>
<script>
    export default {
        name : "FooterComp"
    }
</script>
<style></style>