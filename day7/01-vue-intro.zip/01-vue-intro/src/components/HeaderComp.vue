<template>
    <header>
        <h2>Sports Interactive Mumbai</h2>
        <h3>Tagline...</h3>
    </header>
</template>

<script>
    export default {
        name : "HeaderComp"
    }
</script>

<style scoped>

</style>