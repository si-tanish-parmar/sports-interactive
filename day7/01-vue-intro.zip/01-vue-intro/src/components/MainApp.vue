<template>
  <div>
    <h1>{{ msg }}</h1>
    <header-comp></header-comp>
    <main-comp></main-comp>
    <footer-comp></footer-comp>
  </div>
</template>

<script>
import HeaderComp from "./HeaderComp.vue";
import FooterComp from "./FooterComp.vue";
import MainComp from "./MainComp.vue";

export default {
  name: 'MainApp',
  components : {
    HeaderComp,
    FooterComp,
    MainComp
  },
  props: {
    msg: String
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
