<template>
    <main>
        <h1>I am the main tag</h1>
        <!-- <slot></slot> -->
        <my-article-comp></my-article-comp>
        <my-article-comp></my-article-comp>
        <my-article-comp></my-article-comp>
    </main>
</template>
<script>
import MyArticleComp from './MyArticleComp.vue';
    export default {
        name : "MainComp",
        components : {
            MyArticleComp
        }
    }
</script>
<style></style>