<template>
    <article>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Deleniti cum facere esse provident dolores, dolor dolorem magnam eligendi deserunt harum laboriosam aliquam in, hic dolore vero aliquid voluptates voluptate tenetur!
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Beatae, illum doloremque officiis placeat est aperiam incidunt dolorum cupiditate reprehenderit magni asperiores dignissimos, unde corrupti tempore optio rem excepturi assumenda ducimus.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt, quae cupiditate velit fugiat perspiciatis voluptatem ea enim distinctio ipsum consequatur vel quod iure in rem repudiandae! Autem eaque quos quasi.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed vero, quia sequi debitis quo eius, culpa tempora ipsa dolorum libero ad ipsum id iusto! Neque nemo ea dolor nisi tempora.
    </article>
</template>
<script>
    export default {
        name : "MyArticleComp"
    }
</script>
<style></style>