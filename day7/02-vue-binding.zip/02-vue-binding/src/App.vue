<template>
  <div>
    <h1>{{ title }}</h1>
    <h1 v-html="title"></h1>
    <h1 v-text="title"></h1>
    <h1 v-bind:textContent="title"></h1>
    <h1 v-bind:innerText="title"></h1>
    <h1 v-bind:innerHTML="title"></h1>
    <input v-model="title"/>
  </div>
</template>

<script>
export default {
  name: 'App',
  props: {
    msg: String,
  },
  data() {
    return {
      title: "Ironman"
    }
  },
  methods : {
    clickHandler(){
      // title = 'change';
      alert("you clicked the button");
      // console.log(this);
    }
  }
}
</script>
