<template>
  <div>
    <!-- step 1 start -->
    <!-- (h2[v-if="power === $"]{Power is $})*5 -->
    <!-- the number input type converts the data to a number but the range wont-->
    <!-- you will see if the power is string the range will work-->
    <!-- but the input type number wont  -->
    <!-- <input type="range" step="1" v-model="power" min="0" max="20"> -->
    <!-- <input type="number" step="1" v-model="power" min="0" max="20"> -->
    <h2 v-if="power === '0'">Power is 0</h2>
    <h2 v-if="power === '1'">Power is 1</h2>
    <h2 v-if="power === '2'">Power is 2</h2>
    <h2 v-if="power === '3'">Power is 3</h2>
    <h2 v-if="power === '4'">Power is 4</h2>
    <h2 v-if="power === '5'">Power is 5</h2>
    <span></span>
    <h2 v-if="power <= '5'">Power is less than or equal to 5</h2>
    <!-- v-else should immediately follow the if to work -->
    <h2 v-else>Power now is {{ power }} which is greater than 5</h2>
    <input type="number" step="1" v-model="score" min="-5" max="10">
    <h3 v-if="score < 0 ">You Lost</h3>
    <h3 v-else-if="score <= 0">Lets Start </h3>
    <h3 v-else-if="score <= 4">You Must Try Harder</h3>
    <h3 v-else-if="score === 5">You Can Do It</h3>
    <h3 v-else-if="score <= 9">You Are Almost There</h3>
    <h3 v-else> You Won </h3>
    <!-- step 1 end -->

    <!-- if you need to wrap multiple elements based on a condition then wrap it in a template without having to add a div -->

    <!-- step 2 start -->
    <!-- v-show works the same as v-if but v-show will add display:none instead of not creating the dom -->
    <!-- v-show will add display:none and v-if wont create the dom if false -->
      <h2 v-show="title === 'Avenger'">You are an Avenger</h2>
    <!-- step 2 end -->

  </div>
</template>

<script>
  export default {
    data(){
      return {
        title : "Avenger",
        power : "5",
        version : 0,
        score : 4
      }
    },
    components: { }
  }
</script>

<style>
#app {
  font-family: sans-serif;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>