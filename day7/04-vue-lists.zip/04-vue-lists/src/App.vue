<template>
  <div>
    <!-- step 1 start -->
    <!-- v-for will loop over an array, every iteration needs a unique key property -->
    <ol>
      <li v-for="name in avengers" :key="name">{{ name }}</li>
    </ol>
    <!-- step 1 end -->
    <hr>
    
    <!-- step 2 start -->
    <!-- v-for also provides us with a index property that we can use -->
    <ul>
      <li v-for="(hname, index) in avengers" :key="index">{{(index+1) +" "+ hname}}</li>
    </ul>
    <hr>
    <!-- step 2 end -->
    <!-- step 3 start -->
    <!-- iteration with objects -->
    <h3 v-for="(name, index) in names" :key="index">{{(index+1) +". "+ name.title }} is  {{ name.firstname+" "+name.lastname }}</h3>
    <!-- step 3 end -->
    
    <!-- step 4 start -->
     <!--  step3 using object to iterate with destructuring
        <ol>
            <li v-for="{title, firstname} in names" v-bind:key="title">{{ title }}</li>
        </ol> 
    --> 
    <!-- step 4 end -->

    <!-- step 5 start -->
    <!--  step4 using index with destructuring
        <ol>
            <li v-for="({title, firstname}, index) in names" v-bind:key="title">{{ index }} | {{ title }}</li>
        </ol> 
    --> 
    <!-- step 5 end -->


    <!-- step 6 start -->
    <!-- iteration with objects here while iteration you have access to key along with index -->
    <h4 v-for="(detail, key, idx) in project" :key="idx">{{ key }} : {{ detail }}</h4>
    <!-- step 6 end -->
    <hr>
    <!-- step 7 start -->
    <!-- iteration with array of objects -->

     <!-- 
      inside the v-for when we use v-if  
      v-if is looking for a value and the value is not in scope 
      you will get an error so to avoid the error 
      you can use a template tag or 
      elvis operator or 
      v-cloak
      use computed properties 
      -->
      
      <div v-for="(lavenger, index) in ladyAvengers" :key="index">
        <h4>{{(index+1) +". Title "+ lavenger.title }}</h4>
        <span v-if="lavenger?.firstname.length > 0"> Full Name :  {{ lavenger?.firstname+" "+lavenger?.lastname }}</span>
        <article style=" background-color: silver; padding : 10px; width : 300px; margin : auto ">
          <ol v-for="(movie, index) in lavenger.movies" :key="index">{{ movie.title  }}</ol>
        </article>
      </div>
    <!-- step 7 end -->
  </div>
</template>

<script>
  export default {
    beforeCreate(){
      console.log("Component's beforeCreate was called");
    },
    beforeUpdate(){
      console.log("Component's beforeUpdate was called");     
    },
    created(){
      console.log("Component's created was called");     
    },
    beforeMount(){
      console.log("Component's beforeMount was called");     
    },
    mounted(){
      console.log("Component's mounted was called");      
    },
    beforeUnmount(){
      console.log("Component's beforeUnmount was called");      
    },
    unmount(){
      console.log("Component's unmount was called");
    },

    data(){
      return {
        title: "Welcome to VUE Training",
        avengers: ['Black Widow', 'Scarlet Witch', 'Shuri', 'Wasp', 'Captain Marvel', 'Gamora'],
        names: [
          { title: 'Wasp', firstname: "Janet", lastname: 'Van Dyne' },
          { title: 'Scarlet Witch', firstname: "Wanda", lastname: 'Maximoff' },
          { title: 'Black Widow', firstname: "Natasha", lastname: 'Romanoff' },
          { title: 'Captain Marvel', firstname: "Carol", lastname: 'Danvers' },
        ],
        project : {
          apptitle : "Avengers App",
          author : "Vijay",
          version : 101,
          year  :2023
        },
        ladyAvengers: [
          {
            "title": "Wasp",
            "firstname": "Janet",
            "lastname": "Van Dyne",
            "movies": [
              { "title": "Ant-Man", "year": 2015 },
              { "title": "Ant‑Man and the Wasp", "year": 2018 },
              { "title": "Avengers: Endgame", "year": 2019 }
            ]
          },
          {
            "title": "Scarlet Witch",
            "firstname": "Wanda",
            "lastname": "Maximoff",
            "movies": [
              { "title": "Captain America: The Winter Soldier", "year": 2014 },
              { "title": "Avengers: Age of Ultron", "year": 2015 },
              { "title": "Captain America: Civil War", "year": 2016 },
              { "title": "Avengers: Infinity War", "year": 2018 },
              { "title": "Avengers: Endgame", "year": 2019 },
              { "title": "Doctor Strange in the Multiverse of Madness", "year": 2022 }
            ]
          },
          {
            "title": "Black Widow",
            "firstname": "Natasha",
            "lastname": "Romanoff",
            "movies": [
              { "title": "Iron Man 2", "year": 2010 },
              { "title": "Avengers", "year": 2012 },
              { "title": "Captain America: The Winter Soldier", "year": 2014 },
              { "title": "Avengers: Age of Ultron", "year": 2015 },
              { "title": "Captain America: Civil War", "year": 2016 },
              { "title": "Avengers: Infinity War", "year": 2018 },
              { "title": "Avengers: Endgame", "year": 2019 }
            ]
          },
          {
            "title": "Captain Marvel",
            "firstname": "Carol",
            "lastname": "Danvers",
            "movies": [
              { "title": "Captain Marvel", "year": 2019 },
              { "title": "Avengers: Endgame", "year": 2019 }
            ]
          },
          {
            "title": "Gamora",
            "firstname": "",
            "lastname": "",
            "movies": [
              { "title": "Guardians of the Galaxy", "year": 2014 },
              { "title": "Guardians of the Galaxy Vol. 2", "year": 2017 },
              { "title": "Avengers: Infinity War", "year": 2018 },
              { "title": "Avengers: Endgame", "year": 2019 }
            ]
          },
          {
            "title": "Shuri",
            "firstname": "Shuri",
            "lastname": "Princess",
            "movies": [
              { "title": "Black Panther", "year": 2018 },
              { "title": "Avengers: Infinity War", "year": 2018 },
              { "title": "Avengers: Endgame", "year": 2019 },
              { "title": "Black Panther: Wakanda Forever", "year": 2022 }
            ]
          }
]
      }
    },
    components: { }
  }
</script>

<style>
#app {
  font-family: sans-serif;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
#app ol,ul{
  text-align: left;
  width: 300px;
  margin : auto
}
</style>