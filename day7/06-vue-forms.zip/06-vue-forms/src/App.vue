<template>
  <div class="container">
    <pre>{{ JSON.stringify( herodata, null, 1 )}}</pre>
    <hr>
    <div class="mb-3">
      <label for="htitle" class="form-label">Hero Title</label>
      <input v-model="herodata.title" type="text" class="form-control" id="htitle" >
    </div>
    <div class="mb-3">
      <label for="hfname" class="form-label">Hero First Name</label>
      <input v-model="herodata.firstname" type="text" class="form-control" id="hfname" >
    </div>
    <div class="mb-3">
      <label for="hlname" class="form-label">Hero Last Name</label>
      <input v-model="herodata.lastname" type="text" class="form-control" id="hlname" >
    </div>
    <div class="mb-3">
      <label for="hpower" class="form-label">Hero Power</label>
      <input v-model="herodata.power" type="range" class="form-control" id="hpower" >
    </div>
    <div class="mb-3">
      <label for="htype" class="form-label">Hero Type</label>
      <select v-model="herodata.type" id="htype">
        <option selected disabled value="">Select Here</option>
        <option value="avenger">Avenger</option>
        <option value="justiceleague">Justice League</option>
        <option value="indichero">Indic Hero</option>
      </select>
    </div>
    <div>
      <label for="hcf1">
        Can Fight : <input id="hcf1"  v-model="herodata.canfight" type="checkbox"/>
      </label>
      <br>
      <label for="hcf2">
        You can also use change the default boolean to a string like this
        Can Fly : <input id="hcf2" true-value="can fly" false-value="can't fly"  v-model="herodata.canfly" type="checkbox"/>
      </label>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>

    <!-- step 1 end -->
  </div>
</template>

<script>
  export default {
    data(){
      return {
        title : "Welcome to VUE Training",
        herodata : {
          title : '',
          firstname : '',
          lastname : '',
          power : 0,
          type : '',
          canfight : false,
          fly : "can't fly"
        }
      }
    },
    components: { }
  }
</script>

<style>
/*empty */
</style>