
<template>
  <div>
    <!-- step 1 start -->
    <!-- combining data values without computed properties -->
    <h3>without computed properties</h3>
    <h2>{{ firstname+" "+lastname }}</h2>
    <!-- step 1 end -->
    <hr>
    <!-- step 2 start -->
    <!-- combining data values using computed properties -->
    <h3>with computed properties</h3>
    <h2>{{ fullname }}</h2>
    <!-- step 2 end -->
    <hr>

    <!-- step 3 start -->
    <!-- avoid computation and put more logic in template and binding  -->
    <h3>without computed properties</h3>
    <h2>Total Power : {{ avengers.reduce( (initval, hero) => (initval = initval + hero.power) , 0) }}</h2>
    <!-- step 3 end -->
    <hr>
    <!-- step 4 start -->
    <!-- avoid computation and put more logic in template and binding  -->
    <h3>with computed properties</h3>
    <h2>Total Power : {{ totalpower }}</h2>
    <!-- step 4 end -->

    <!-- step 5 start -->
    <!-- avoid computation and put more logic in template and binding  -->
    <h3>Add new Avenger</h3>
    <button @click="this.avengers.push({title : 'Spiderman', power : 6})">Add Avenger</button>
    <!-- step 5 end -->

    <!-- step 6 start -->
    <!-- avoid computation and put more logic in template and binding  -->
    <h3>Using the GetSum</h3>
    <h3>{{ getsum() }}</h3>
    <!-- step 6 end -->

    <!-- step 7 start -->
    <!-- 
      if the values are re-calculated the bindings will be re-assigned and DOM will re-rendered
      here you will see that the getsum is being called for every property change of version 
      but the computed property is not being called every time as it is cached
      hence using computed property is more beneficial than methods
      exercise create a list of heroes who are fit to fight with power more than 5 using computed properties
      solution 
    -->
     <ol>
        <li v-for="hero in strongHeroes" :key="hero.power"> {{ hero.title }} {{ hero.power }} </li>
    </ol>
    Version : {{ version }}
    <input type="number" v-model="version"> 
    <!-- step 7 end -->

    <!-- step 8 computed list start -->
    
   
    
    <!-- step 8 end -->

    <!-- step 9 start -->
    <!-- computed properties can also be getters and setters  -->
    <h4>Version is {{ accessVersion }}</h4>
    <button @click="accessVersion = 10">Set Version to 10</button>
    <!-- step 9 end -->
    
  </div>
</template>

<script>
  export default {
    data(){
      return {
        title : "Welcome to VUE Training",
        firstname : "Bruce",
        lastname : "Wayne",
        version : 0,
        avengers : [
          { title : "Ironman", power : 7 },
          { title : "Antman", power : 6 },
          { title : "Thor", power : 4 },
          { title : "Hulk", power : 9 },
          { title : "Captain America", power : 8 }
        ],
        getsum : function(){
          console.log("getsum was called ",Math.random() )
          return this.avengers.reduce( (initval, hero) => (initval = initval + hero.power) , 0)
        }
      }
    },
    computed : {
      fullname(){
        return `${ this.firstname } ${this.lastname }`
      },
      totalpower(){
        console.log("totalpower was called ",Math.random() );          
        return this.avengers.reduce( (initval, hero) => (initval = initval + hero.power) , 0)
      },
      strongHeroes(){
          return this.avengers.filter(avenger => avenger.power > 5 ); 
      },       
      accessVersion :{
        get(){ return this.version },
        set(nversion){ this.version = nversion }
      }
      
    },
    components: { }
  }
</script>

<style>
#app {
  font-family: sans-serif;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>