<template>
  <div>
    <h1>global and local components</h1>
    <my-local-comp></my-local-comp>
    <my-global-comp></my-global-comp>
  </div>
</template>

<script>
import MyLocalComp from './components/MyLocalComp.vue'
export default {
  name: 'App',
  components : {
    MyLocalComp
}
}
</script>

<style>

</style>
