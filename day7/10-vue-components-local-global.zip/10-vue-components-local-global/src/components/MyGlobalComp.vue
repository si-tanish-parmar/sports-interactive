<template>
    <div>
        <h2>I am a Global Component</h2>
    </div>
</template>
<script>
    export default {
        name : "MyGlobalComp"
    }
</script>
<style>
</style>