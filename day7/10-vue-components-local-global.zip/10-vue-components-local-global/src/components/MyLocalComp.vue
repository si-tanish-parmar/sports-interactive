<template>
    <div>
        <h2>I am a Local Component</h2>
    </div>
</template>
<script>
    export default {
        name : "MyLocalComp"
    }
</script>
<style>
</style>