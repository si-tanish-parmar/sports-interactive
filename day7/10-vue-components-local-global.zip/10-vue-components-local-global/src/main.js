import { createApp } from 'vue';
import App from './App.vue';
import MyGlobalComp from "./components/MyGlobalComp.vue"

//make sure that the mount is called after the components are attached
const app = createApp(App);
app.component('MyGlobalComp', MyGlobalComp);
app.mount("#app");