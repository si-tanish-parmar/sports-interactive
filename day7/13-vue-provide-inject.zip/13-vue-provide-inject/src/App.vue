<template>
  <div>
    <!-- step 1 start -->
    <FamGrand/> 
    <!-- step 1 end -->
 </div>
</template>

<script>
  import FamGrand from "./components/grand.vue";
  export default {
    name : "App",
    data(){
      return {
        title : "Welcome to VUE Training"
      }
    },
    components: { 
      FamGrand
    }
  }
</script>

<style>
#app {
  font-family: sans-serif;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>