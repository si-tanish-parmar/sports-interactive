<template>    
    <div class="box">
        <h2>Grand Parent Component</h2>
        <input type="text" v-model="message">
        <FamParent/>
    </div>
</template>

<script>
    import FamParent from "./parent.vue"
    export default {
        name : "FamGrand",
        data(){
            return {
                message : "default message"
            }
        },
        components: { 
          FamParent
        },
        provide(){
            return {
                message : this.message
            }
        }
    }
</script>

<style>
   .box{
    border:  2px solid rgb(221, 71, 71);
    padding: 10px;
    margin: 10px;
    text-align: left;
    max-width: 600px;
   }
</style>