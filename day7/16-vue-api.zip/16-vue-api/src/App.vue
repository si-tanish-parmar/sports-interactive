<template>
  <div>
    <AppUsers/>
  </div>
</template>

<script>
import AppUsers from "./components/users.vue"

export default {
  name: 'App',
  components: {
    AppUsers
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
