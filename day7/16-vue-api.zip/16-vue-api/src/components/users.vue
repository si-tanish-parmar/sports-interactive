<template>  
    <div>
      <pre>{{ JSON.stringify(users) }}</pre>
      <button @click="getUsers">Get Data</button>
      <ol>
        <li v-for="user in users" :key="user.id">{{ user.first_name }}</li>
      </ol>
    </div>
  </template>
  
  <script>
  import axios from "axios";
    export default {
     name : "AppUsers",
      data(){
        return {
          users : []
        }
      },
      methods : {
        /* getUsers(){
          axios.get("https://reqres.in/api/users?page=2")
          .then( res => console.log( res.data.data ))
          .catch( err => console.log( err ))
        } */
        getUsers(){
          axios.get("https://reqres.in/api/users?page=2")
          .then( res => this.users = res.data.data )
          .catch( err => console.log( err ))
        }
      }
    }
  </script>
  
  <style>

  </style>