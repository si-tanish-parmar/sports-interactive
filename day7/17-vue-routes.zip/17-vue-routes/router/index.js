import { createRouter } from "vue-router";
import HomeComp from "../components/HomeComp.vue";
import BatmanComp from "../components/BatComp.vue";
import SupermanComp from "../components/SuperComp.vue";
import FlashComp from "../components/FlashComp";

export default createRouter({
    routes : [
        {
            path : "/",
            name : "Home",
            component : HomeComp
        },
        {
            path : "/batman",
            name : "Batman",
            component : BatmanComp
        },
        {
            path : "/superman",
            name : "Superman",
            component : SupermanComp
        },
        {
            path : "/flash",
            name : "Flash",
            component : FlashComp
        },
    ]
})