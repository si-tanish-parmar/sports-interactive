<template>
    <div>
        <h1>Flash Component</h1>
    </div>
</template>
<script>
    export default {
        name : "FlashComp"
    }
</script>
<style>
</style>