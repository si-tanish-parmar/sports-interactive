<template>
    <div>
        <h1>Home Component</h1>
    </div>
</template>
<script>
    export default {
        name : "HomeComp"
    }
</script>
<style>
</style>