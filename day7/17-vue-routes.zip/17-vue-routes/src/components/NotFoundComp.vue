<template>
    <div>
        <h1>NotFound Component</h1>
        <h2>404 Page Not Found</h2>
    </div>
</template>
<script>
    export default {
        name : "NotFoundComp"
    }
</script>
<style>
</style>