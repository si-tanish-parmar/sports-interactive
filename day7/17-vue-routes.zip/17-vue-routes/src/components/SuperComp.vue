<template>
    <div>
        <h1>Superman Component</h1>
    </div>
</template>
<script>
    export default {
        name : "SupermanComp"
    }
</script>
<style>
</style>